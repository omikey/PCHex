#!/bin/bash

mkdir -p export/PCHex
cp -rf data PCHex.3dsx PCHex.smdh PCHex.xml export/PCHex

